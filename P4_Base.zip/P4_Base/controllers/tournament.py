class TournamentController:  # ici on defini la classe TournamentController qui aura plusieurs méthodes à implementer

    def handle_tournament(self):  # méthode handle tournament (gérer le tournoi), methode à completer
        print("Gestion des tournois")        
        input('\nAppuyez sur Entreé pour continuer ')
