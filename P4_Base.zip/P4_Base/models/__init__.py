'''
Les fichiers __init__.py sont nécessaires pour que Python 
considère les dossiers comme contenant des paquets, cela 
évite que des dossiers ayant des noms courants comme string 
ne masquent des modules qui auraient été trouvés plus tard 
dans la recherche des dossiers.

'''