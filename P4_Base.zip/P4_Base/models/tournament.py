
# ici implementation de la class tournament

"""Classe tournament"""

class Tournament:
    """Represents a tournament"""